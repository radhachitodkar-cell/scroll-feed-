# ScrollFeed — Research Study Interface

## Deploy to Vercel (2 minutes)

1. Install Vercel CLI: `npm install -g vercel`
2. Run: `vercel --prod` from this folder
3. Or drag this folder to vercel.com/new

## Deploy to Netlify (30 seconds)
1. Go to netlify.com/drop
2. Drag the `public/` folder onto the page
3. Done — instant live URL

## Deploy to GitHub Pages
1. Push this repo to GitHub
2. Settings → Pages → Deploy from `/public` on main branch

## Local test
Open `public/index.html` in any browser — no server needed.
